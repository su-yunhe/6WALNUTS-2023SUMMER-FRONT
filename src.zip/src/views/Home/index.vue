<script setup>
import HomeNav from './components/HomeNav.vue'
// import HomeHeader from './components/HomeHeader.vue'
// import HomeHeaderFix from './components/HomeHeaderFix.vue'
// import HomeMain from './components/HomeMain.vue'
import HomeFooter from './components/HomeFooter.vue'


</script>

<template>
  <HomeNav />
  <!-- <HomeHeader />
  <HomeHeaderFix /> -->
  <el-backtop :right="100" :bottom="300" />
  <RouterView />
  <!-- <HomeMain /> -->
  <HomeFooter />
</template>


<style scoped lang="scss">

</style>