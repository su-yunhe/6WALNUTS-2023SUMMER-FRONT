<template>
  <div class="container">
    某一个项目
    <div class="blank"></div>
  </div>
  
</template>

<style scoped>
.blank {
  height: 1000px
}
</style>